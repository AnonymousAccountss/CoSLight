import random

# import gfootball.env as football_env
from onpolicy.envs.sumo_files_marl.env.sim_env import TSCSimulator
from onpolicy.envs.sumo_files_marl.config import config

from gym import spaces
import numpy as np

import torch
import copy
import os, sys

# output_path


class SUMOEnv(object):
    '''Wrapper to make Google Research Football environment compatible'''

    def __init__(self, args, rank):
        
        self.args = args
        id = args.seed + np.random.randint(0, 2023) + rank
        self.set_seed(id)
        
        # make env
        env_config = config['environment']
        # sumo_envs_num = len(env_config['sumocfg_files'])
        sumo_cfg = args.sumocfg_files
        sumo_cfg = os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + '/' + sumo_cfg    
        
        env_config = copy.deepcopy(env_config)
        env_config['sumocfg_file'] = sumo_cfg
        port = args.port_start + id
        
        # print('------------------------', port )
        print('----port--', port, '----sumo_cfg--', sumo_cfg)
        
        output_path = config.get("environment").get("output_path")
        output_path = output_path + env_config['sumocfg_files'][0].split('/')[-2] + '/trial_' + str(id) + '/'
        if not os.path.exists(output_path):
            os.makedirs(output_path)
        self.env = TSCSimulator(env_config, port, output_path=output_path)
        
        self.unava_phase_index = []
        for i in self.env.all_tls:
            self.unava_phase_index.append(self.env._crosses[i].unava_index)
   
        self.num_agents = len(self.unava_phase_index)
        self.action_space = []
        self.observation_space = []
        self.share_observation_space = []
                
        for idx in range(self.num_agents):
            self.action_space.append(spaces.Discrete(n=env_config['num_actions']))
            self.share_observation_space.append(spaces.Box(-float('inf'), float('inf'), [env_config['obs_shape']*self.num_agents], dtype=np.float32))
            self.observation_space.append(spaces.Box(-float('inf'), float('inf'), [env_config['obs_shape']], dtype=np.float32))
        

    def get_unava_phase_index(self):
        return np.array(self.unava_phase_index)
    
    def set_seed(self, seed):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        return

    def get_reward(self, reward, all_tls):
        ans = []
        for i in all_tls:
            ans.append(sum(reward[i].values()))
        return np.array(ans)


    # def batch(self, env_output, use_keys, all_tl):
    #     """Transform agent-wise env_output to batch format."""
    #     if all_tl == ['gym_test']:
    #         return torch.tensor([env_output])
    #     obs_batch = {}
    #     for i in use_keys+['mask', 'neighbor_index', 'neighbor_dis']:
    #         obs_batch[i] = []
    #     for agent_id in all_tl:
    #         out = env_output[agent_id]
    #         tmp_dict = {k: np.zeros(8) for k in use_keys}
    #         state, mask, neight_msg = out
    #         for i in range(len(state)):
    #             for s in use_keys:
    #                 tmp_dict[s][i] = state[i].get(s, 0)
    #         for k in use_keys:
    #             obs_batch[k].append(tmp_dict[k])
    #         obs_batch['mask'].append(mask)
    #         obs_batch['neighbor_index'].append(neight_msg[0][0])
    #         obs_batch['neighbor_dis'].append(neight_msg[0][1])

    #     for key, val in obs_batch.items():
    #         if key not in ['current_phase', 'mask', 'neighbor_index']:
    #             obs_batch[key] = np.array(val)
    #         else:
    #             obs_batch[key] = np.array(val)
                
    #     self.obs_keys = list(obs_batch.keys())
    #     obs_values = np.hstack(list(obs_batch.values())) ### 25, 64
    #     return obs_values
    
    
    
    # def batch(self, env_output, use_keys, all_tl):
    #     """Transform agent-wise env_output to batch format."""
    #     if all_tl == ['gym_test']:
    #         return torch.tensor([env_output])
    #     obs_batch = {}
    #     for i in use_keys+['mask']:
    #         obs_batch[i] = []
    #     for agent_id in all_tl:
    #         out = env_output[agent_id]
    #         tmp_dict = {k: np.zeros(8) for k in use_keys}
    #         state, mask = out
    #         for i in range(len(state)):
    #             for s in use_keys:
    #                 tmp_dict[s][i] = state[i].get(s, 0)
    #         for k in use_keys:
    #             obs_batch[k].append(tmp_dict[k])
    #         obs_batch['mask'].append(mask)

    #     # for key, val in obs_batch.items():
    #     #     if key not in ['current_phase', 'mask']:
    #     #         obs_batch[key] = torch.FloatTensor(np.array(val))
    #     #     else:
    #     #         obs_batch[key] = torch.LongTensor(np.array(val))
        
    #     for key, val in obs_batch.items():
    #         # if key != 'pressure':
    #         if key not in ['current_phase', 'mask']:
    #             obs_batch[key] = np.array(val)
    #         else:
    #             obs_batch[key] = np.array(val)
                
    #     ###### 把 pressure 放在字典最后面
    #     obs_batch['pressure'] = obs_batch.pop('pressure')
    #     self.obs_keys = list(obs_batch.keys())
    #     obs_values = np.hstack(list(obs_batch.values())) ### 25, 56
    #     #### max-pressure
        
    #     #### A: wt-et B: el-et C: wl-wt D: el-wl E: nt-st F: sl-st G: nt-nl H: nl-sl
    #     ####    3  7     6   7    2  3      2  6    1   5    4   5    0   1     0  4
    #     # obs_batch['pressure'] 
    #     return obs_values
    
    def batch(self, env_output, use_keys, all_tl):
        """Transform agent-wise env_output to batch format."""
        if all_tl == ['gym_test']:
            return torch.tensor([env_output])
        obs_batch = {}
        for i in use_keys+['mask', 'neighbor_index', 'neighbor_dis']:
            obs_batch[i] = []
        for agent_id in all_tl:
            out = env_output[agent_id]
            tmp_dict = {k: np.zeros(8) for k in use_keys}
            state, mask, neight_msg = out
            for i in range(len(state)):
                for s in use_keys:
                    tmp_dict[s][i] = state[i].get(s, 0)
            for k in use_keys:
                obs_batch[k].append(tmp_dict[k])
            obs_batch['mask'].append(mask)
            obs_batch['neighbor_index'].append(neight_msg[0][0])
            obs_batch['neighbor_dis'].append(neight_msg[0][1])

        for key, val in obs_batch.items():
            if key not in ['current_phase', 'mask', 'neighbor_index']:
                obs_batch[key] = torch.FloatTensor(np.array(val))
            else:
                obs_batch[key] = torch.LongTensor(np.array(val))

        ###### 把 pressure 放在字典最后面
        
        if self.args.use_pressure:
            obs_batch['pressure'] = obs_batch.pop('pressure')
        else:
            obs_batch.pop('pressure')
            
        if self.args.use_gat:
            obs_batch['neighbor_index'] = obs_batch.pop('neighbor_index')
            obs_batch['neighbor_dis'] = obs_batch.pop('neighbor_dis')
        else:
            obs_batch.pop('neighbor_index')
            obs_batch.pop('neighbor_dis')
        
        self.obs_keys = list(obs_batch.keys())
        obs_values = np.hstack(list(obs_batch.values())) ### 25, 56
        
        
        return obs_values


    
    # def reverse_batch(self, obs_values):
    #     batch_dict = {}
    #     lengths = [8,8,8,8,8,8,8, 4,4]  # ['current_phase', 'car_num', 'queue_length', 'occupancy', 'flow', 'stop_car_num', 'mask', 'neighbor_index', 'neighbor_dis']
    #     begin = 0
    #     for i in range(self.obs_keys):
    #         if self.obs_keys[i] not in ['current_phase', 'mask', 'neighbor_index']:
    #             batch_dict[self.obs_keys[i]] = torch.FloatTensor(obs_values[:,begin:begin+lengths[i]])
    #         else:
    #             batch_dict[self.obs_keys[i]] = torch.LongTensor(obs_values[:,begin:begin+lengths[i]])
                
    #     return batch_dict
                
    
    def reset(self):
        obs = self.env.reset()
        obs_values = self.batch(obs, config['environment']['state_key'], self.env.all_tls)
        obs_values = self._obs_wrapper(obs_values)
        return obs_values

    def step(self, action):
        tl_action_select = {}
        for tl_index in range(len(self.env.all_tls)):
            tl_action_select[self.env.all_tls[tl_index]] = \
                (self.env._crosses[self.env.all_tls[tl_index]].green_phases)[action[tl_index]]
        obs, reward, done, info = self.env.step(tl_action_select)
        obs = self.batch(obs, config['environment']['state_key'], self.env.all_tls)
        obs = self._obs_wrapper(obs)
        reward = self.get_reward(reward, self.env.all_tls)
        reward = reward.reshape(self.num_agents, 1)
        # if self.share_reward:
        #     global_reward = np.sum(reward)
        #     reward = [[global_reward]] * self.num_agents
        
        # info['individual_reward'] = reward

        done = np.array([done] * self.num_agents)
        # info = self._info_wrapper(info)
        return obs, reward, done, info

    def seed(self, seed=None):
        if seed is None:
            random.seed(1)
        else:
            random.seed(seed)

    def close(self):
        self.env.close()

    def _obs_wrapper(self, obs):
        if self.num_agents == 1:
            return obs[np.newaxis, :]
        else:
            return obs

    # def _info_wrapper(self, info):
    #     state = self.env.unwrapped.observation()
    #     info.update(state[0])
    #     info["max_steps"] = self.max_steps
    #     info["active"] = np.array([state[i]["active"] for i in range(self.num_agents)])
    #     info["designated"] = np.array([state[i]["designated"] for i in range(self.num_agents)])
    #     info["sticky_actions"] = np.stack([state[i]["sticky_actions"] for i in range(self.num_agents)])
    #     return info
