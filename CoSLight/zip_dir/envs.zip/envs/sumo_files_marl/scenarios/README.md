## Sumo Envs
Now, there are 5 base environments for training agents. The env of Fenglin road is based on real word roadmap and od!

Example scenarios:  
- Large grid(5*5):  ![img.png](img.png)
- Fenglin road: ![img_4.png](img_4.png)
- Nanshan: ![img_1.png](img_1.png)
- ![img_2.png](img_2.png)
- ![img_3.png](img_3.png)

### Usage
First, you need to [install sumo](https://sumo.dlr.de/docs/Downloads.php).

Then you can use "sumo-gui" to visualize and interact with envs, just to open simulation with *.sumocfg file in each scenario's folder.

